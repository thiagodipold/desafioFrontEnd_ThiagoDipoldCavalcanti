# Desafio Front End  


Olá 👋


## Objetivo

Criar uma interface web para consulta de endereço a partir do CEP, baseado no design na pasta em anexo.
Sua tarefa é construir o projeto a partir do design que está na pasta '/design'. Utilize as fontes que estão na pasta assets. Adicione o que achar necessário referente ao design e ao fluxo de tela. 

## Requisitos:

- Ser uma interface responsiva. 
- Não fazer trocas de URLS
- Usar esta API aberta de consulta de CEP: https://viacep.com.br/
- Disponibilizar aplicação em um projeto privado no github e permitir acesso ao e-mail cristhiane.resende@levelup.com.br. 
- Utilizar HTML, CSS e Javascript e/ou Jquery. 
 

**Divirta-se e boa sorte!** 🚀

